const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const router = express.Router();
const { MongoClient } = require('mongodb'); // MongoDB client
const session = require('express-session'); // Import express-session
const app = express();
const PORT = process.env.PORT || 3000;

// MongoDB connection URI and database name
const uri = 'mongodb://localhost:27017/'; // Change this to your MongoDB URI
const dbName = 'Pets_Management_System';

// Middleware to parse form data (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Set up session middleware
app.use(session({
    secret: 'your_secret_key', // Replace with a strong secret key
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set secure: true in production with HTTPS
}));

// Serve static files from the public directory
app.use(express.static('public'));

// Route to serve front.html as the entry point
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'front.html'));
});

// Route to handle error page
app.get('/error', (req, res) => {
    res.send(`<h1>Error occurred</h1><p>Something went wrong. Please try again later.</p>`);
});

// POST route to handle form submission at /sign_up
app.post('/sign_up', async (req, res) => {
    const formData = req.body; // Form data received

    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

        await client.connect();
        console.log('Connected to MongoDB');

        const db = client.db(dbName);
        const collection = db.collection('Login_Signup');

        // Insert form data into the 'Login_Signup' collection
        await collection.insertOne(formData);

        console.log('Form Data Saved:', formData);

        // Close the MongoDB connection
        await client.close();

        // Redirect to success.html after form submission
        res.sendFile(path.join(__dirname, 'public', 'success.html'));
    } catch (error) {
        console.error('Error connecting to MongoDB or saving data:', error);
        res.status(500).send('Error saving data.');
    }
});

// Login Route
app.post('/login', async (req, res) => {
    const { ownername, password } = req.body;
    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Login_Signup');
        const user = await collection.findOne({ ownername, password });

        if (user) {
            // Store ownername in session
            req.session.ownername = ownername;

            // Redirect to dashboard.html after login
            res.redirect('/dashboard');
        } else {
            // Incorrect credentials
            res.send(`<script>alert('Password incorrect!'); window.location.href = "/login.html";</script>`);
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.redirect('/error');
    } finally {
        await client.close();
    }
});

// Serve the Dashboard page
app.get('/dashboard', (req, res) => {
    if (!req.session.ownername) {
        // Redirect to login if not logged in
        res.redirect('/login.html');
    } else {
        // Serve dashboard.html if logged in
        res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
    }
});

// API route to get dashboard data
app.get('/api/dashboard-data', async (req, res) => {
    const ownername = req.session.ownername; // Get ownername from session

    if (!ownername) {
        return res.status(401).send('Unauthorized: No ownername found');
    }

    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Login_Signup');
        const user = await collection.findOne({ ownername });

        if (user) {
            res.json({ ownername: user.ownername, petName: user.petName });
        } else {
            res.status(404).send('User not found');
        }

        await client.close();
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).send('Server error');
    }
});

app.get('/api/hos-data', async (req, res) => {
    const ownername = req.session.ownername; // Get ownername from session

    if (!ownername) {
        return res.status(401).send('Unauthorized: No ownername found');
    }

    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Hospitals');
        const user = await collection.findOne({ ownername });

        if (user) {
            res.json({ ownername: user.ownername, hospitalName: user.hospitalName });
        } else {
            res.status(404).send('User not found');
        }

        await client.close();
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).send('Server error');
    }
});

app.post('/add_pet', async (req, res) => {
    const { petName, species, breed, lastVaccination } = req.body; // Extract pet data
    const ownername = req.session.ownername; // Get ownername from session

    if (!ownername) {
        return res.status(401).send('Unauthorized: No ownername found');
    }

    const petData = { petName, species, breed, lastVaccination, ownername }; // Create pet data object
    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Pet_Details'); // Create a Pets collection or use your existing one

        // Insert pet data into the 'Pets' collection
        await collection.insertOne(petData);

        console.log('Pet Data Saved:', petData);

        await client.close();

        // Redirect to a success page or send a response
        res.send('<h1>Pet Registered Successfully</h1><a href="/dashboard">Go back to Dashboard</a>');
    } catch (error) {
        console.error('Error connecting to MongoDB or saving pet data:', error);
        res.status(500).send('Error saving pet data.');
    }
});


app.get('/api/vaccination-details', async (req, res) => {
    const ownername = req.session.ownername;

    if (!ownername) {
        return res.status(401).send('Unauthorized: No ownername found');
    }

    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Pet_Details');
        
        // Fetch all pets for the owner
        const pets = await collection.find({ ownername }).toArray();

        if (pets.length > 0) {
            // Map pets to vaccination details
            const vaccinationDetails = pets.map(pet => ({
                petName: pet.petName,
                vaccine: pet.lastVaccination, // Assuming lastVaccination is the vaccine date
                date: pet.lastVaccination // You may want to change this to a specific vaccination date if available
            }));
            res.json(vaccinationDetails);
        } else {
            res.status(404).send('No pets found for this owner');
        }
    } catch (error) {
        console.error('Error fetching vaccination details:', error);
        res.status(500).send('Server error');
    } finally {
        await client.close();
    }
});

// Logout Route
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error during logout:', err);
            return res.redirect('/error');
        }
        res.redirect('/'); // Redirect to home page after logout
    });
});

app.get('/api/appointment-details', async (req, res) => {
    const ownername = req.session.ownername;

    if (!ownername) {
        return res.status(401).send('Unauthorized: No ownername found');
    }

    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('Pet_Details');

        // Fetch all pets for the owner
        const pets = await collection.find({ ownername }).toArray();

        if (pets.length > 0) {
            // Calculate next appointment date (6 months after last vaccination)
            const appointmentDetails = pets.map(pet => {
                const lastVaccinationDate = new Date(pet.lastVaccination);
                const nextAppointmentDate = new Date(lastVaccinationDate);
                nextAppointmentDate.setMonth(nextAppointmentDate.getMonth() + 6); // Add 6 months

                return {
                    petName: pet.petName,
                    nextAppointment: nextAppointmentDate.toDateString() // Convert to readable date string
                };
            });

            res.json(appointmentDetails); // Send appointment details to front-end
        } else {
            res.status(404).send('No pets found for this owner');
        }
    } catch (error) {
        console.error('Error fetching appointment details:', error);
        res.status(500).send('Server error');
    } finally {
        await client.close();
    }
});

app.use(express.json());
const hospitalSelectionSchema = new mongoose.Schema({
    ownername: String,
    hospitalName: String
});

const HospitalSelection = mongoose.model('Hospitals', hospitalSelectionSchema);

app.post('/save-hospital-selection', async(req, res) => {
    console.log('Received data:', req.body); // Log the incoming request data
    const { ownername, hospitalName } = req.body;
    const formData=req.body;
    try{
    
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
    console.log('Connected to MongoDB');

    const db = client.db(dbName);
    const collection = db.collection('Hospitals');
  
        // Insert form data into the 'Login_Signup' collection
    await collection.insertOne(formData);

    console.log('Form Data Saved:', formData);
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
        // Close the MongoDB connection
    await client.close();}
    catch(error){console.error('Error connecting to MongoDB or saving data:', error);
        res.status(500).send('Error saving data.');}
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
